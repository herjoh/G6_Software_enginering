package com.example.g6brombrom.testing.ubtegrationTests;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class HttpResponseTest {

    @Test
    void getCode() {
    }

    @Test
    void getMessage() {
    }

    @Test
    void testToString() {
    }
}