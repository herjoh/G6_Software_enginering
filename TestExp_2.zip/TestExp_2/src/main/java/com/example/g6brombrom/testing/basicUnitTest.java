package com.example.g6brombrom.testing;


public class basicUnitTest {

    public int add(int a, int b) {
        return a + b;
    }

}