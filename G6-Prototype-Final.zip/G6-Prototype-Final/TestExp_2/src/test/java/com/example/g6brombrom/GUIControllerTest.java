package com.example.g6brombrom;

import static org.junit.jupiter.api.Assertions.*;

class GUIControllerTest {

}