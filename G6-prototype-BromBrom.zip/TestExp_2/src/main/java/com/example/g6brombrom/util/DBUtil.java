package com.example.g6brombrom.util;


import javax.sql.rowset.CachedRowSet;
import javax.sql.rowset.RowSetFactory;
import javax.sql.rowset.RowSetProvider;
import java.sql.*;

public class DBUtil {

    private static Connection conn = null;


    private static final String connStr = "jdbc:sqlite:src/main/java/com/example/g6brombrom/DataBase/karsdb.db.db";

    public static void dbConnect() throws SQLException {

        try {
            conn = DriverManager.getConnection(connStr);

        } catch (SQLException e) {
            System.out.println("Connection Failed! Check output console" + e);
            e.printStackTrace();
            throw e;
        }
    }



    public static void dbDisconnect() throws SQLException {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
            }
        } catch (Exception e){
            throw e;
        }
    }


    public static ResultSet dbExecuteQuery(String queryStmt) throws SQLException, ClassNotFoundException {

        Statement stmt = null;
        ResultSet resultSet = null;

        RowSetFactory factory = RowSetProvider.newFactory();
        CachedRowSet crs = factory.createCachedRowSet();
        try {
            dbConnect();

            stmt = conn.createStatement();


            resultSet = stmt.executeQuery(queryStmt);


            crs.populate(resultSet);
        } catch (SQLException e) {
            System.out.println("Problem occurred at executeQuery operation : " + e);
            throw e;
        } finally {
            if (resultSet != null) {

                resultSet.close();
            }
            if (stmt != null) {

                stmt.close();
            }

            dbDisconnect();
        }

        return crs;
    }

    public static void dbPreparedStatementUpdateString(String query,String regnr,String endring) throws SQLException {
        try {
            dbConnect();
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1,endring);
            stmt.setString(2,regnr);
            stmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println(e);

        }
        dbDisconnect();
    }

    public static void dbPreparedStatementUpdateInt(String query,String regnr,int endring) throws SQLException {
        try {
            dbConnect();
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1,endring);
            stmt.setString(2,regnr);
            stmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println(e);

        }
        dbDisconnect();
    }

    public static void dbPreparedStatementDelete(String query,String regnr) throws SQLException {
        try {
            dbConnect();
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1,regnr);
            stmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println(e);

        }
        dbDisconnect();
    }

    public static void dbExecuteUpdate(String sqlStmt) throws SQLException, ClassNotFoundException {

        Statement stmt = null;
        try {

            dbConnect();

            stmt = conn.createStatement();

            stmt.executeUpdate(sqlStmt);
        } catch (SQLException e) {
            System.out.println("Problem occurred at executeUpdate operation : " + e);
            throw e;
        } finally {
            if (stmt != null) {

                stmt.close();
            }

            dbDisconnect();
        }
    }
}