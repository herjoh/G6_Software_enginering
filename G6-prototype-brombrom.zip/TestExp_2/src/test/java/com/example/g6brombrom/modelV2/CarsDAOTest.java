package com.example.g6brombrom.modelV2;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CarsDAOTest {

    @Test
    void searchCars() {
    }

    @Test
    void deleteCar() {
    }

    @Test
    void updateCarMerke() {
    }

    @Test
    void updateCarModell() {
    }

    @Test
    void updateCarEier() {
    }

    @Test
    void updateCarFarge() {
    }

    @Test
    void updateCarOmråde() {
    }

    @Test
    void updateCarledigDato() {
    }

    @Test
    void updateCarLedig() {
    }

    @Test
    void updateCarÅrsModell() {
    }

    @Test
    void updateCarRegnr() {
    }

    @Test
    void insertCar() {
    }
}