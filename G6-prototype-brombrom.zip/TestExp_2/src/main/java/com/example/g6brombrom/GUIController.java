package com.example.g6brombrom;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import com.example.g6brombrom.modelV2.Cars;
import com.example.g6brombrom.modelV2.CarsDAO;
import com.example.g6brombrom.util.DBUtil;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class GUIController {

    @FXML
    private TextField merkefelt;
    @FXML
    private TextField modellfelt;
    @FXML
    private TextField eierfelt;
    @FXML
    private TextField årsmodellfelt;
    @FXML
    private TextField fargefelt;
    @FXML
    private TextField områdefelt;
    @FXML
    private TextField ledigfelt;
    @FXML
    private TextField ledigdatofelt;
    @FXML
    private TextField regnr;
    @FXML
    private TableView tableid;
    @FXML
    private TextField insert;
    @FXML
    private TableColumn <Cars, String>  merkeIdColum;
    @FXML
    private TableColumn <Cars, String>  modelIdColum;
    @FXML
    private TableColumn <Cars, String>  eierIdColum;
    @FXML
    private TableColumn <Cars, Integer>  årsmodelIdColumn;
    @FXML
    private TableColumn <Cars, String>  fargeIdColumn;
    @FXML
    private TableColumn <Cars, String>  områdeIdColumn;
    @FXML
    private TableColumn <Cars, Boolean>  ledigIdColumn;
    @FXML
    private TableColumn <Cars, String>  datoIdColumn;
    @FXML
    private TableColumn <Cars, String>  regnrIdColumn;
    @FXML
    private ListView<String> terminal;
    @FXML
    private ListView<String> leidbilid_3;

    private ObservableList<String> terminalOutput = FXCollections.observableArrayList("resultater fra dine handlinger vil vises her: ");
    private ObservableList<String> leidbilOutput = FXCollections.observableArrayList("Liste over leide biler:");

    @FXML
    private void initialize () throws SQLException, ClassNotFoundException {

        merkeIdColum.setCellValueFactory(cellData -> cellData.getValue().merkeProperty());
        modelIdColum.setCellValueFactory(cellData -> cellData.getValue().modellProperty());
        eierIdColum.setCellValueFactory(cellData -> cellData.getValue().eierProperty());
        årsmodelIdColumn.setCellValueFactory(cellData -> cellData.getValue().årsmodellProperty().asObject());
        fargeIdColumn.setCellValueFactory(cellData -> cellData.getValue().fargeProperty());
        områdeIdColumn.setCellValueFactory(cellData -> cellData.getValue().områdeProperty());
        ledigIdColumn.setCellValueFactory(cellData -> cellData.getValue().tilgjengligProperty().asObject());
        datoIdColumn.setCellValueFactory(cellData -> cellData.getValue().ledigdatoProperty());
        regnrIdColumn.setCellValueFactory(cellData -> cellData.getValue().regestreringsNummerProperty());

        showTable();
        leidbilid_3.setItems(leidbilOutput);
        terminal.setItems(terminalOutput);
    }


    @FXML
    private void searchCars(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
        try {

            ObservableList<Cars> carData =  getCarFromResultSet(DBUtil.dbExecuteQuery("SELECT * from cars"));

            populateCars(carData);

        } catch (SQLException e){
            System.out.println("Error occurred while getting employees information from DB.\n" + e);
            throw e;
        }
    }
    private static ObservableList<Cars> getCarFromResultSet(ResultSet rs) throws SQLException
    {
        ObservableList<Cars> empList = FXCollections.observableArrayList();

        while (rs.next()) {
            Cars emp = new Cars();
            emp.setMerke(rs.getString("merke"));
            emp.setModell(rs.getString("modell"));
            emp.setEier(rs.getString("eier"));
            emp.setÅrsmodell(rs.getInt("årsmodell"));
            emp.setFarge(rs.getString("farge"));
            emp.setOmråde(rs.getString("område"));
            emp.setTilgjenglig(Boolean.parseBoolean(rs.getString("tilgjenglig")));
            emp.setledigdato(rs.getString("ledigdato"));
            emp.setRegestreringsNummer(rs.getString("regnr"));

            empList.add(emp);
        }
        return empList;
    }

    @FXML
    private void showTable() throws SQLException, ClassNotFoundException {
        try {

            ObservableList<Cars> carData =  getCarFromResultSet(DBUtil.dbExecuteQuery("SELECT * from cars"));

            populateCars(carData);
        } catch (SQLException e){
            System.out.println("Error occurred while getting information from DB.\n" + e);
            throw e;
        }
    }


    @FXML
    private void populateCars (ObservableList<Cars> carData) throws ClassNotFoundException {


        tableid.setItems(carData);
    }
    @FXML
    private void deleteCar (ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
        try {

            if (!Objects.equals(insert.getText(),"")) {
                CarsDAO.deleteCar(insert.getText());
                updateLeidBilListe(insert.getText(), "del");
                showTerminalMessage("Bilen eid av: " + eierfelt.getText() + " Med registreringsnummeret: " + insert.getText() + " har blitt slettet.");
            } else {
                showTerminalMessage("Du må skrive inn et regnr for å kunne slette en bil");
            }
        } catch (SQLException e) {

            throw e;
        }
    }


    @FXML
    private void insertCar (ActionEvent actionEvent) throws SQLException, ClassNotFoundException {

        try {
            if (!Objects.equals(merkefelt.getText(),"") || !Objects.equals(modellfelt.getText(),"") ||
                    !Objects.equals(eierfelt.getText(),"") || !Objects.equals(årsmodellfelt.getText(),"") ||
                    !Objects.equals(fargefelt.getText(),"") || !Objects.equals(områdefelt.getText(),"") ||
                    !Objects.equals(ledigfelt.getText(),"") || !Objects.equals(ledigdatofelt.getText(),"") ||
                    !Objects.equals(regnr.getText(),"")){
                CarsDAO.insertCar(merkefelt.getText(), modellfelt.getText(), eierfelt.getText(),
                        årsmodellfelt.getAnchor(), fargefelt.getText(), områdefelt.getText(),
                        ledigfelt.getText(), ledigdatofelt.getText(), regnr.getText());
                showTerminalMessage("Bilen eid av: " + eierfelt.getText() + " Med registreringsnummeret: " + regnr.getText() + " har blitt lagt til.");
            } else {
                showTerminalMessage("Et av feltene er ikke fylt inn, fyll inn alle felt for å legge til bil");
            }
        } catch (SQLException e) {

            throw e;
        }
    }

    @FXML
    private void leiBil (ActionEvent actionEvent) throws SQLException,ClassNotFoundException {
        try {
            if (!Objects.equals(insert.getText(),"")) {
                String regnr = insert.getText();
                CarsDAO.updateCarLedig(regnr, "FALSE");
                updateLeidBilListe(regnr, "add");
                showTerminalMessage("Bilen eid av: " + eierfelt.getText() + " Med registreringsnummeret: " + insert.getText() + " har blitt leid.");
            } else {
                showTerminalMessage("vennligst skriv inn et regnr.");
            }
        } catch (SQLException e) {
            throw e;
        }
    }


    @FXML
    private void updateCar(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
        String[] collumnNames = {"merke", "modell", "eier", "årsmodell", "farge", "område", "tilgjenglig", "ledigdato", "regnr"};
        ResultSet rs = DBUtil.dbExecuteQuery("SELECT * from cars");

        if (Objects.equals(insert.getText(), "")) {
            showTerminalMessage("Du må skrive inn et regnr for å kunne oppdatere biler.");
        } else {
            while (rs.next()) {
                if (!Objects.equals(rs.getString(collumnNames[0]), merkefelt.getText())&&!Objects.equals(merkefelt.getText(), "")) {CarsDAO.updateCarMerke(insert.getText(), merkefelt.getText());}
                if (!Objects.equals(rs.getString(collumnNames[1]), modellfelt.getText())&&!Objects.equals(modellfelt.getText(), "")) {CarsDAO.updateCarModell(insert.getText(), modellfelt.getText());}
                if (!Objects.equals(rs.getString(collumnNames[2]), eierfelt.getText())&&!Objects.equals(eierfelt.getText(), "")) {CarsDAO.updateCarEier(insert.getText(), eierfelt.getText());}
                if (!Objects.equals(rs.getString(collumnNames[3]), årsmodellfelt.getText())&&!Objects.equals(årsmodellfelt.getText(), "")) {CarsDAO.updateCarÅrsModell(insert.getText(), Integer.parseInt(årsmodellfelt.getText()));}
                if (!Objects.equals(rs.getString(collumnNames[4]), fargefelt.getText())&&!Objects.equals(fargefelt.getText(), "")) {CarsDAO.updateCarFarge(insert.getText(), fargefelt.getText());}
                if (!Objects.equals(rs.getString(collumnNames[5]), områdefelt.getText())&&!Objects.equals(områdefelt.getText(), "")) {CarsDAO.updateCarOmråde(insert.getText(), områdefelt.getText());}
                if (!Objects.equals(rs.getString(collumnNames[6]), ledigfelt.getText())&&!Objects.equals(ledigfelt.getText(), "")) {CarsDAO.updateCarLedig(insert.getText(), ledigfelt.getText());}
                if (!Objects.equals(rs.getString(collumnNames[7]), ledigdatofelt.getText())&&!Objects.equals(ledigdatofelt.getText(), "")) {CarsDAO.updateCarledigDato(insert.getText(), ledigdatofelt.getText());}
                if (!Objects.equals(rs.getString(collumnNames[8]), insert.getText())&&!Objects.equals(insert.getText(), "")) {CarsDAO.updateCarRegnr(insert.getText(), regnr.getText());}
            }
            showTerminalMessage("Bilen eid av: "+eierfelt.getText()+" Med registreringsnummeret: "+insert.getText()+" har blitt oppdatert.");
        }
    }
    private void showTerminalMessage(String msg) {
        terminalOutput.add(msg);
        terminal.setItems(terminalOutput);
    }

    private void updateLeidBilListe(String regnr,String mode) throws SQLException, ClassNotFoundException {
        if (Objects.equals(mode,"add")) {
            leidbilOutput.add(regnr);
            leidbilid_3.setItems(leidbilOutput);
        } else if (Objects.equals(mode,"del")) {
            leidbilOutput.remove(regnr);
        }
        leidbilid_3.setItems(leidbilOutput);
    }



}

